xbioc
=====

This R package provides extra utility functions to perform common tasks in 
the analysis of omic data, leveraging and enhancing features provided 
by Bioconductor packages.
