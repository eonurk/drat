# Project: xbioc
# 
# Author: Renaud Gaujoux
# Created: Jul 3, 2014
###############################################################################

#' @docType package
#' @importFrom stats setNames
#' @import stringr
NULL
