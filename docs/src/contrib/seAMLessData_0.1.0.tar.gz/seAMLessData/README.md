## seAMLessData

A data package for [seAMLess](https://github.com/eonurk/seAMLess) package on CRAN. Due to package size limitations policies of CRAN, the single cell atlases used in the package are stored here and lazy-loaded.
